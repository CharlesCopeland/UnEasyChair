Rails.application.routes.draw do
  
  
  resources :ps
  devise_for :accounts,  :controllers => { :registrations => 'registrations' }
  
  resources :tracks
  get 'tracks/index'
  
  get 'a_tracks' => 'tracks#a', as: 'a_tracks'
  get 'b_tracks' => 'tracks#b', as: 'b_tracks'
  get 'c_tracks' => 'tracks#c', as: 'c_tracks'
  get 'd_tracks' => 'tracks#d', as: 'd_tracks'
  get 'e_tracks' => 'tracks#e', as: 'e_tracks'
  
  
  resources :accounts
  get 'accounts/index'
  
  resources :conferences
  get 'conferences/index'
  
  resources :authors do
    resources :papers

    
end


resources :conferences do
  resources :tracks
end

resources :tracks do
  resources :papers
end
  
  
  resources :chairs do
    resources :conferences

end
  resources :chairs, only: [:edit, :update, :change]
  
  resources :authors, only: [:edit, :update]
  resources :pcmembers, only: [:edit, :update]
  resources :pcchairs, only: [:edit, :update]

  namespace :admin do
    resources :chairs
    resources :pcchairs
    resources :pcmembers
    resources :authors
    resources :users
    resources :papers
    root to: "users#index"
  end


  #get 'admin' => 'admin#index'

  controller :sessions do
    get 'login' => :new
    post 'login' => :create
    delete 'logout' => :destroy
 end

  get 'sessions/create'

  get 'sessions/destroy'

  resources :users
  resources :papers
  get 'home/homepage'
  get 'home/login'
  get 'home/signup'
  get 'home/contact'
  get 'home/authors'
  root  'home#homepage'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
