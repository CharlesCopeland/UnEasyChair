require 'test_helper'

class PcmemberTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
