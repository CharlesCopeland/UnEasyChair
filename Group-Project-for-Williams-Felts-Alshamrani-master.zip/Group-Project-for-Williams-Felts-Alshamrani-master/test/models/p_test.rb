require 'test_helper'

class PTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
