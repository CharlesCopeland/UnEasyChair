require 'test_helper'

class PcchairTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
