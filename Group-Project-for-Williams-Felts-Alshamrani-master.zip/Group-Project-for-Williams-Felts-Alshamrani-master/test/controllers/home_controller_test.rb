require 'test_helper'

class HomeControllerTest < ActionDispatch::IntegrationTest
<<<<<<< HEAD
  # test "the truth" do
  #   assert true
  # end
=======
  test "should get homepage" do
    get home_homepage_url
    assert_response :success
  end

>>>>>>> b3e526e741d1eba5e0ecdd4ca5084c7ffbabd234
end
