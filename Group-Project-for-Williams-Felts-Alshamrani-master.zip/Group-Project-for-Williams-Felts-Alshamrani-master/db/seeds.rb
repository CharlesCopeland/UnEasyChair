# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

Account.destroy_all
Chair.destroy_all
Author.destroy_all
Conference.destroy_all
Paper.destroy_all
Pcchair.destroy_all
Pcmember.destroy_all
Track.destroy_all
User.destroy_all

accounts = Account.create([{
    email: "chair1@uneasychair.com",
    encrypted_password: "changeme",
},
{
    email: "chair2@uneasychair.com",
    encrypted_password: "changeme",
},
{
    email: "author1@uneasychair.com",
    encrypted_password: "changeme",
},
{
    email: "author2@uneasychair.com",
    encrypted_password: "changeme",
},
{
    email: "pcmember1@uneasychair.com",
    encrypted_password: "changeme",
},
{
    email: "pcmember2@uneasychair.com",
    encrypted_password: "changeme",
},
{
    email: "pcchair1@uneasychair.com",
    encrypted_password: "changeme",
},
{
    email: "pcchair2@uneasychair.com",
    encrypted_password: "changeme",
}])
p "Created #{accounts.count} accounts"




users = User.create([{
    name: "John",
    password_digest: "changeme",
},
{
    name: "Susan",
    password_digest: "changeme",
},
{
    name: "Mark",
    password_digest: "changeme",
},
{
    name: "Charles",
    password_digest: "changeme",
},
{
    name: "Elizabeth",
    password_digest: "changeme",
},
{
    name: "Micheal",
    password_digest: "changeme",
},
{
    name: "Julie",
    password_digest: "changeme",
},
{
    name: "Tom",
    password_digest: "changeme",
},
{
    name: "Erica",
    password_digest: "changeme",
},
{
    name: "Brandon",
    password_digest: "changeme",
}])
p "Created #{users.count} users"




chairs = Chair.create([{
    name: "John",
},
{
    name: "Susan",
}])
p "Created #{chairs.count} chairs"

authors = Author.create([{
     name: "Mark",
},
{
     name: "Charles",
}])
p "Created #{authors.count} authors"








conferences = Conference.create([{
    name: "The Planetary Society",
},
{
    name: "Mathematics and Computer Science",
},
{
    name: "The History of Everything",
},
{
    name: "Coding with Ruby on Rails",
},
{
    name: "How to Beat the Coding Interview",
},
{
    name: "Valdosta State University",
},
{
    name: "Life at Google.com",
},
{
    name: "Who is Edward Snowden",
},
{
    name: "Discovering National Treasures",
},
{
    name: "Breaking Out of Your Shell",
},
{
    name: "Creating Customer Connections",
},
{
    name: "Dedicated to Your Success",
},
{
    name: "Innovate, Integrate, Motivate!",
},
{
    name: "Leadership Next: Defying Gravity",
},
{
    name: "Growing Your Business",
},
{
    name: "Selling Beyond Price",
},
{
    name: "Tean Impact",
},
{
    name: "Right Time Right Now",
},
{
    name: "The 2017 Presidential Election",
},
{
    name: "The Chemistry of the Brain",
}])

p "Created #{conferences.count} conferences"



tracks = Track.create([{
    tittle: "How Big is the Universe?",
    conference: "The Planetary Society",
},
{
    tittle: "Geometry and Other Topics",
    conference: "Mathematics and Computer Science",
},
{
    tittle: "How to do Binary Division",
    conference: "Mathematics and Computer Science",
},
{
    tittle: "Guides for Setting Up Ruby with Cloud9.io",
    conference: "Coding with Ruby on Rails",
},
{
    tittle: "Interview Topics",
    conference: "How to Beat the Coding Interview",
},
{
    tittle: "Registration Tips",
    conference: "Valdosta State University",
},
{
    tittle: "Campus Hot Spots",
    conference: "Valdosta State University",
},
{
    tittle: "Football",
    conference: "Valdosta State University",
},
{
    tittle: "Touring Yellowstone National Park",
    conference: "Discovering National Treasures",
},
{
    tittle: "Driving Cross Country",
    conference: "Discovering National Treasures",
},
{
    tittle: "Across the Galaxy in 7 Days",
    conference: "The Planetary Society",
},
{
    tittle: "Plotting the Constellations",
    conference: "The Planetary Society",
},
{
    tittle: "Orbits and Kepler's Laws",
    conference: "The Planetary Society",
},
{
    tittle: "Discoveries of Extra-Solar System Planets: Exoplanets",
    conference: "The Planetary Society",
},
{
    tittle: "How to be a Successful Entrepreneur",
    conference: "Growing Your Business",
},
{
    tittle: "Why Does Price Really Matter?",
    conference: "Selling Beyond Price",
},
{
    tittle: "Keeoing Your Team Focused",
    conference: "Team Impact",
},
{
    tittle: "Staying Productive",
    conference: "Right Time Right Now",
},
{
    tittle: "Poll Results",
    conference: "The 2017 Presidential Election",
},
{
    tittle: "Mind Over Matter",
    conference: "The Chemistry of the Brain",
}])

p "Created #{tracks.count} tracks"