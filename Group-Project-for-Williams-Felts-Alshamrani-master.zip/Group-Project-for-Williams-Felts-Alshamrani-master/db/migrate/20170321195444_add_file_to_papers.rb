class AddFileToPapers < ActiveRecord::Migration[5.0]
  def change
    add_column :papers, :file, :string
  end
end
