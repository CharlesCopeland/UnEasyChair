class AddConferenceToPs < ActiveRecord::Migration[5.0]
  def change
    add_column :ps, :conference, :string
  end
end
