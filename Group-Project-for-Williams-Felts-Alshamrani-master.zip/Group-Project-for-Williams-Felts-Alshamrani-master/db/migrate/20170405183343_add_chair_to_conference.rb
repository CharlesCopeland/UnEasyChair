class AddChairToConference < ActiveRecord::Migration[5.0]
  def change
    add_reference :conferences, :chair, foreign_key: true
  end
end
