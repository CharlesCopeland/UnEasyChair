class AddTrackToPapers < ActiveRecord::Migration[5.0]
  def change
    add_column :papers, :track, :string
  end
end
