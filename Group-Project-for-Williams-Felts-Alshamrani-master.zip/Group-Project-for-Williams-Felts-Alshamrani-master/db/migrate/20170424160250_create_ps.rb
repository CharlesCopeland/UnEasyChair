class CreatePs < ActiveRecord::Migration[5.0]
  def change
    create_table :ps do |t|
      t.string :Pc
      t.string :name
      t.string :owner

      t.timestamps
    end
  end
end
