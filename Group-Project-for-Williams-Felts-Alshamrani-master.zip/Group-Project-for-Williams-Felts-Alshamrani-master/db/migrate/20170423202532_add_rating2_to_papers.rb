class AddRating2ToPapers < ActiveRecord::Migration[5.0]
  def change
    add_column :papers, :rating2, :decimal, :default => 0
  end
end
