class AddRollToUsers < ActiveRecord::Migration[5.0]
  def change
    add_column :users, :roll, :string
  end
end
