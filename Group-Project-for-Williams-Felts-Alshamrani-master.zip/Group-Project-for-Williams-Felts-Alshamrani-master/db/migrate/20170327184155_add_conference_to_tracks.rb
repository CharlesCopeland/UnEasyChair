class AddConferenceToTracks < ActiveRecord::Migration[5.0]
  def change
    add_column :tracks, :conference, :string
  end
end
