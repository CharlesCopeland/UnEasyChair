class AddChairToPaper < ActiveRecord::Migration[5.0]
  def change
    add_reference :papers, :chair, foreign_key: true
  end
end
