class AddWantToAccounts < ActiveRecord::Migration[5.0]
  def change
    add_column :accounts, :want, :string, :default => 'no'
  end
end
