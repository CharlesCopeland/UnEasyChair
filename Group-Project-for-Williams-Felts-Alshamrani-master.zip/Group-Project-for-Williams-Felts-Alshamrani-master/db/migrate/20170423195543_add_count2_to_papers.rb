class AddCount2ToPapers < ActiveRecord::Migration[5.0]
  def change
    add_column :papers, :count2, :integer, :default => 0
  end
end
