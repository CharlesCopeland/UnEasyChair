class AuthorsController < ApplicationController
  before_action :authenticate_account!
  before_action :set_author, only: [:edit, :update]


  def pundit_user
     current_account
  end
  
  # GET /authors/1/edit
  def edit
    authorize @author
  end

  # PATCH/PUT /authors/1
  # PATCH/PUT /authors/1.json
  def update
    authorize @author
    respond_to do |format|
      if @author.update(author_params)
        format.html { redirect_to home_homepage_url, notice: "The profile of the author #{@author.name} was successfully updated." }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @author.errors, status: :unprocessable_entity }
      end
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_author
      @author = Author.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def author_params
      params.require(:author).permit(:name, :address, :pay_type)
    end
end