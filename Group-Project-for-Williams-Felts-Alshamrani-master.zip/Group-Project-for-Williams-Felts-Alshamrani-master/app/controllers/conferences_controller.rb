class ConferencesController < ApplicationController
  before_action :authenticate_account!
  before_action :set_conference, only: [:show, :edit, :update, :destroy]

  def pundit_user
    current_account
  end
  
  # GET /conferences
  # GET /conferences.json
  def index
    #if (params[:chair_id])
     # @chair = Chair.find(params[:chair_id])
      #@conferences = @chair.conferences
    #else
     # @conferences = Conference.all
    #end
    
    authorize Conference
    @conferences = policy_scope(Conference)
  end

  # GET /conferences/1
  # GET /conferences/1.json
  def show
     authorize Conference
     @tracks = Track.all
     @papers = Paper.all
     @ps = P.all
     @conference = Conference.find(params[:id])
  end

  # GET /conferences/new
  def new
    @conference = Conference.new
     authorize Conference
  end

  # GET /conferences/1/edit
  def edit
     authorize Conference
  end

  # POST /conferences
  # POST /conferences.json
  def create
    @conference = Conference.new(conference_params)
     authorize Conference
     if current_account && current_account.accountable_type == "Chair"
        @conference.chair = current_account.accountable
     end

    respond_to do |format|
      if @conference.save
        format.html { redirect_to @conference, notice: 'Conference was successfully created.' }
        format.json { render :show, status: :created, location: @conference }
      else
        format.html { render :new }
        format.json { render json: @conference.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /conferences/1
  # PATCH/PUT /conferences/1.json
  def update
     authorize Conference
    respond_to do |format|
      if @conference.update(conference_params)
        format.html { redirect_to @conference, notice: 'Conference was successfully updated.' }
        format.json { render :show, status: :ok, location: @conference }
      else
        format.html { render :edit }
        format.json { render json: @conference.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /conferences/1
  # DELETE /conferences/1.json
  def destroy
     authorize Conference
    @conference.destroy
    respond_to do |format|
      format.html { redirect_to conferences_url, notice: 'Conference was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_conference
      @conference = Conference.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def conference_params
      params.require(:conference).permit(:name, :users)
    end
end
