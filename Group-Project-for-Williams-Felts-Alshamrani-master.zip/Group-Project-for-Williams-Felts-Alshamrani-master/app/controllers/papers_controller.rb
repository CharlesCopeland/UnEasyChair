class PapersController < ApplicationController
  before_action :set_paper, only: [:show, :edit, :update, :destroy]
  
  before_action :authenticate_account!
  
  def pundit_user
    current_account
  end

  # GET /papers
  # GET /papers.json
  def index
  #  if (params[:author_id])
  #    @author = Author.find(params[:author_id])
  #    @papers = @author.papers
  #  else
  #    @papers = Paper.all
  #  end
  #end
  
  authorize Paper 
    @papers = policy_scope(Paper)
  
  end

  # GET /papers/1
  # GET /papers/1.json
  def show
    authorize @paper
  end

  # GET /papers/new
  def new
    @paper = Paper.new
    authorize @paper
     @tittle = params[:tittle]
  end

  # GET /papers/1/edit
  def edit
    authorize @paper
    if current_account.accountable_type == "Pcmember"
      @paper.update_attributes(:count2 => @paper.count2 + 1)
    end
  end
  
  def rate
  end

  # POST /papers
  # POST /papers.json
  def create
    @paper = Paper.new(paper_params)
    authorize @paper
    
    if current_account && current_account.accountable_type == "Author"
        @paper.author = current_account.accountable
    end

    respond_to do |format|
      if @paper.save
        format.html { redirect_to @paper, notice: 'Paper was successfully created.' }
        format.json { render :show, status: :created, location: @paper }
      else
        format.html { render :new }
        format.json { render json: @paper.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /papers/1
  # PATCH/PUT /papers/1.json
  def update
    authorize @paper
    respond_to do |format|
      if @paper.update(paper_params)
        format.html { redirect_to @paper, notice: 'Paper was successfully updated.' }
        format.json { render :show, status: :ok, location: @paper }
      else
        format.html { render :edit }
        format.json { render json: @paper.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /papers/1
  # DELETE /papers/1.json
  def destroy
    authorize @paper
    @paper.destroy
    respond_to do |format|
      format.html { redirect_to papers_url, notice: 'Paper was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_paper
      @paper = Paper.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def paper_params
      params.require(:paper).permit(:title, :description, :author, :file, :author_id, :track, :reviews, :status, :comments, :rating, :rating2)
    end
end
