module PapersHelper
end
