class ChairPolicy
  attr_reader :current_account, :model

  def initialize(current_account, model)
    @current_account = current_account
    @chair = model
  end

  def edit?
    @current_account == @chair.account
  end

  def update?
    @current_account == @chair.account
  end

end