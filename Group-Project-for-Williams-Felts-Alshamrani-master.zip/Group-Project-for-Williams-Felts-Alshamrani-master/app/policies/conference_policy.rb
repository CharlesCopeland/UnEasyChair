class ConferencePolicy
  attr_reader :current_account, :model

  def initialize(current_account, model)
    @current_account = current_account
    @conference = model
  end

  def index?
    current_account.accountable_type == "Chair" ||
     current_account.accountable_type == "Author" ||
     current_account.accountable_type == "SuperAccount" ||
     current_account.accountable_type == "Pcmember"||
     current_account.accountable_type == "Pcchair"
  end

  def show?
    current_account.accountable_type == "Chair" ||
    current_account.accountable_type == "Author" ||
    current_account.accountable_type == "Pcmember"||
     current_account.accountable_type == "Pcchair"
  end

  def new?
    current_account.accountable_type == "Chair" 

  end

  def create?
    current_account.accountable_type == "Chair"
  end

  def edit?
    current_account.accountable_type == "Chair"
  end

  def update?
    current_account.accountable_type == "Chair"
  end

  def destroy?
    current_account.accountable_type == "Chair"
  end

  class Scope < Struct.new(:current_account, :model)
    def resolve
       # model.where(chair: current_account.accountable)
       if current_account.accountable_type == "Author" ||
          current_account.accountable_type == "SuperAccount" ||
          current_account.accountable_type == "Pcmember"||
          current_account.accountable_type == "Pcchair"
          model.all
       elsif current_account.accountable_type == "Chair" 
          model.where(chair: current_account.accountable)
      
       end
    end
  end
end