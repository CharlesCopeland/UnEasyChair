class PaperPolicy
  attr_reader :current_account, :model

  def initialize(current_account, model)
    @current_account = current_account
    @paper = model
  end

  def index?
    current_account.accountable_type == "Author" ||
    current_account.accountable_type == "Pcmember" ||
    current_account.accountable_type == "Pcchair" ||
    current_account.accountable_type == "Chair"
  end

  def show?
    @current_account == @paper.author.account ||
    current_account.accountable_type == "Pcmember" ||
    current_account.accountable_type == "Pcchair" ||
    current_account.accountable_type == "Chair"
  end

  def new?
    current_account.accountable_type == "Author"
  end

  def create?
    current_account.accountable_type == "Author"
  end

  def edit?
    @current_account == @paper.author.account ||
    current_account.accountable_type == "Pcchair" ||
    current_account.accountable_type == "Pcmember"
  end

  def update?
    @current_account == @paper.author.account ||
    current_account.accountable_type == "Pcchair" ||
    current_account.accountable_type == "Pcmember"
  end

  def destroy?
    @current_account == @paper.author.account
  end

  class Scope < Struct.new(:current_account, :model)
    def resolve
        
        #model.where(author: current_account.accountable)
        if current_account.accountable_type == "Chair" ||
          current_account.accountable_type == "SuperAccount" ||
          current_account.accountable_type == "Pcmember"||
          current_account.accountable_type == "Pcchair"
          model.all
       elsif current_account.accountable_type == "Author" 
          model.where(author: current_account.accountable)
        end
    end
  end

end