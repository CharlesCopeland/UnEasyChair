class Chair < ApplicationRecord
  has_one :account, as: :accountable
  has_many :conferences
  has_many :ps
end
