class Conference < ApplicationRecord
    belongs_to :chair 
end
