class Author < ApplicationRecord
  has_many :papers
  has_one :account, as: :accountable
end
