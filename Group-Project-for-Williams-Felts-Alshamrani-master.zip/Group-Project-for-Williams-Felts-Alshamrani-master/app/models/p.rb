class P < ApplicationRecord
end
