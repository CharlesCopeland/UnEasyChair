class Pcmember < ApplicationRecord
  has_one :account, as: :accountable
end
