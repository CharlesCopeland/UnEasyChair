class Track < ApplicationRecord
end
