class Paper < ApplicationRecord
    belongs_to :author
    mount_uploader :file, FileUploader
end
